% Xdot = A X + B U + G W
% Y    = C X + D U + H W + V

% A'P + P A - P B K + Q = 0     Riccati equation
% A'P A + Q - A'P C (C' P C + R)^(-1)C' P A = 0     MATLAB version discrete
% Algebraic ricati equation
% KF= A P C' /(C P C' + R)    n*p matrix

% verify that
% A0 = A - KF * C     has negative eigen values

clear all
clc
format bank;
A=[-0.025 0.074 -0.804 -9.809 0;-0.242 -2.017 73.297 -0.105 -0.001;0.003 -0.135 -2.941 0 0 ; 0 0 1 0 0 ; -0.011 1  0 -75 0];
eig(A);
B=[4.594 0;-0.0004 -13.735;0.0002 -24.410 ; 0 0; 0 0];
C= eye(5)-[0.9 0 0 0 0;0 0 0 0 0;0 0 0.5 0 0;0 0 0 0 0;0 0 0 0 0 ];
% the measurement is not complete, we are just getting some signals
D=zeros(5,2);
G=eye(5);
H=zeros(5,5);
states={'u','w','q','theta','h'};
inputs={'thrust','elevator'};
outputs=states;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Syst=ss(A,B,C,D,'statename',states,'inputname',inputs,'outputname',outputs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dt=0.01;
SystD=c2d(Syst,dt,'zoh');
Ad=SystD.A;
eig(Ad);  % must be normed less than 1
Bd=SystD.B;
Cd=SystD.C;
Dd=SystD.D;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=0.01*eye(5);   % process noise covariance
R=0.05*eye(5);    % Measurement noise covariance
llll=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Syst_KF=ss(Ad,[Bd G],Cd,[Dd H],dt); % Disturbed system

[Kest,KF,P]=kalman (Syst_KF,Q,R,0);

KF2= Ad*P*Cd' /(Cd*P*Cd' + R); % second method to confirm the calculation

Error=norm(abs(KF-KF2))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STABILITY of the filter 
A0=Ad-KF*Cd;
eig(A0);
